■説明（Japanese)

yomox9サーバーのmaps,materials,models,sound フォルダのセットです
初めてyomox9サーバーに接続する人におすすめ。 

初めてyomox9サーバーに接続する人、もしくはNMRiHを再インストールした人はカスタムモデル等のために大量のファイルが自動的にダウンロードされ時間がかかります（一度ダウンロードすればOKですが)。 
このファイルパックをインストールすると、最初のファイルダウンロード時間を減らす事が出来ます。

FilePack_Map_yyyymmdd_HHMMSS.zip = マップファイル。サーバー09(DL速い_スキン等無し_初心者用) でのみプレイする場合は、これだけでもいいです。
FilePack_Skin_yyyymmdd_HHMMSS.zip = スキンファイル(materials/models)
FilePack_Sound_yyyymmdd_HHMMSS.zip = サウンドファイル

手順：
FilePack_XXX_yyyymmdd_HHMMSS.zip を展開した後、maps/materials/models/sound フォルダを NoMoreRoominHell のフォルダ（ 一般的には C:\Program Files (x86)\Steam\SteamApps\common\nmrih\nmrih ）に上書きコピーして下さい。 


■Description (English)

This is include maps/materials/models/sound folder for yomox9 server
If you never connect yomox9 server( or you reinstalled NMRIH ), When you do this, the download will be faster

FilePack_Map_yyyymmdd_HHMMSS.zip = Only map files.
FilePack_Skin_yyyymmdd_HHMMSS.zip = Only skin(materials/models) files.
FilePack_Sound_yyyymmdd_HHMMSS.zip = Only sound files.

Procedure:
1. extract .zip 
2. move maps/materials/models/sound forlder to NoMoreRoominHell folder
( C:\Program Files (x86)\Steam\SteamApps\common\nmrih\nmrih ). overwrite ok

■yomox9サーバー一覧 ( yomox9 server list ) 

server02 = nmrih.yomox9.club:28016
server03 = nmrih.yomox9.club:28017
server04 = nmrih.yomox9.club:28018
server05 = nmrih.yomox9.club:28019
server06 = nmrih.yomox9.club:28020
server07 = nmrih.yomox9.club:28021
server08 = nmrih.yomox9.club:28022
server09 = nmrih.yomox9.club:28023
server10 = nmrih.yomox9.club:28024


■サーバー情報等 ( Information )
http://steamcommunity.com/groups/yomox9servers
E-mail : yomox9@gmail.com
